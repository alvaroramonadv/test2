import ModernLandingPage from "@/components/ModernLandingPage";

const Index = () => {
  return <ModernLandingPage />;
};

export default Index;
